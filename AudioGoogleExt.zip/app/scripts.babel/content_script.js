console.log('Find audio files');

var audios = document.getElementsByTagName('audio');
var aux;
var audio;

for (var i=0; i < audios.length; i++) {
  aux = document.getElementsByClassName('audio')[i];
  if (aux !== undefined) {
    audio = aux.getElementsByTagName('audio')[0];
    if (audio !== undefined) {
      var src = audio.getAttribute('src');
      var myRegexp = /[^\/]+$/g;
      var fileName = myRegexp.exec(src)[0];

      var a = document.createElement('a');
      var linkText = document.createTextNode('Download');
      a.appendChild(linkText);
      a.title = 'Click to download';
      a.style.cssText = 'position:absolute;z-index:100;top:0;right:0;padding:2px;background:red;color:#fff;border:1px solid #fff;text-decoration:none;border-radius: 5px;';
      a.href = src;
      a.target = '_blank';
      a.download = fileName + '.ogg';
      aux.appendChild(a);
    }
  }
}
