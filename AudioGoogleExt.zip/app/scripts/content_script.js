'use strict';

console.log('Find audio files');

var audios = document.getElementsByTagName('audio');

for (var index in audios) {
  var aux = document.getElementsByClassName('audio')[index];
  var audio = aux.getElementsByTagName('audio')[0];
  if (audio !== undefined) {
    var src = audio.getAttribute('src');
    var myRegexp = /[^\/]+$/g;
    var fileName = myRegexp.exec(src)[0];

    var a = document.createElement('a');
    var linkText = document.createTextNode('Download');
    a.appendChild(linkText);
    a.title = 'Download here';
    a.style.cssText = 'position:absolute;z-index:100;top:0px;right:-10px;padding:2px;background:red;color:#fff;';
    a.href = src;
    a.target = '_blank';
    a.download = fileName + '.ogg';
    aux.appendChild(a);
  }
}